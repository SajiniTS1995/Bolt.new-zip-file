import React from 'react';
import { Shield, Check } from 'lucide-react';

const CTASection = () => {
  return (
    <section className="py-20 bg-blue-600 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-7/12 mb-8 md:mb-0">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to ensure the safety and reliability of your power systems?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Schedule a consultation with our experts and take the first step toward complete electrical safety and compliance.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {[
                'Comprehensive system assessment',
                'Detailed safety recommendations',
                'Standard-compliant documentation',
                'Ongoing technical support'
              ].map((benefit, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 mr-2">
                    <Check className="h-5 w-5 text-blue-200" />
                  </div>
                  <span className="text-blue-100">{benefit}</span>
                </div>
              ))}
            </div>
            <button className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-md font-medium transition-colors shadow-lg">
              Schedule Your Analysis Today
            </button>
          </div>
          
          <div className="md:w-4/12 flex justify-center">
            <div className="bg-white bg-opacity-10 p-8 rounded-lg border border-white border-opacity-20 backdrop-blur-sm">
              <div className="flex justify-center mb-6">
                <Shield className="h-20 w-20 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-center mb-4">Our Promise</h3>
              <p className="text-center text-blue-100 mb-0">
                Where Proactive Safety Meets Power Engineering
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;