import React, { useState, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';

const slides = [
  {
    title: "Electrical Reliability From Impeccable Power System Analysis",
    description: "We deliver comprehensive power system consulting with a focus on safety, reliability, and industry compliance.",
    cta: "Schedule Your Analysis Today",
    image: "https://images.pexels.com/photos/1435581/pexels-photo-1435581.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    title: "Assured Safety and Resilience",
    description: "Our meticulous analysis prevents system failures and ensures complete compliance with industry standards.",
    cta: "Learn More",
    image: "https://images.pexels.com/photos/257886/pexels-photo-257886.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    title: "Tailor-made Solutions for Every Industry",
    description: "From utilities to manufacturing, we provide specialized power system solutions for your unique challenges.",
    cta: "Explore Our Services",
    image: "https://images.pexels.com/photos/8960464/pexels-photo-8960464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];

const Hero = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <section className="relative h-screen overflow-hidden">
      {/* Background with parallax effect */}
      {slides.map((slide, index) => (
        <div 
          key={index}
          className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
            currentSlide === index ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="absolute inset-0 bg-black/50 z-10" />
          <img 
            src={slide.image} 
            alt={slide.title}
            className="absolute w-full h-full object-cover object-center"
          />
        </div>
      ))}
      
      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center pt-16">
        <div className="max-w-3xl text-white">
          {slides.map((slide, index) => (
            <div 
              key={index}
              className={`transition-all duration-1000 ease-in-out ${
                currentSlide === index 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-8 absolute'
              }`}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {slide.title}
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-gray-100">
                {slide.description}
              </p>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium flex items-center space-x-2 transition-colors">
                <span>{slide.cta}</span>
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
        
        {/* Slide indicators */}
        <div className="absolute bottom-12 left-0 right-0 flex justify-center space-x-2">
          {slides.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full transition-all ${
                currentSlide === index ? 'bg-white w-8' : 'bg-white/50'
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;