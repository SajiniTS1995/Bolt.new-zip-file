import React from 'react';
import { Calendar, Clock, ChevronRight } from 'lucide-react';

const blogPosts = [
  {
    title: "Understanding Arc Flash Hazards in Industrial Settings",
    excerpt: "Learn about the critical dangers of arc flash incidents and how proper analysis can prevent catastrophic outcomes in industrial facilities.",
    date: "June 15, 2023",
    readTime: "5 min read",
    image: "https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    title: "The Impact of IEEE 1584-2018 Updates on Arc Flash Studies",
    excerpt: "Explore how the latest IEEE standards have changed arc flash analysis methodologies and what this means for your facility's safety protocols.",
    date: "July 8, 2023",
    readTime: "7 min read",
    image: "https://images.pexels.com/photos/8850749/pexels-photo-8850749.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    title: "Optimizing Power Flow: Best Practices for Energy Efficiency",
    excerpt: "Discover strategies to enhance your power system's efficiency through advanced load flow studies and intelligent distribution design.",
    date: "August 22, 2023",
    readTime: "6 min read",
    image: "https://images.pexels.com/photos/355948/pexels-photo-355948.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];

const BlogInsights = () => {
  return (
    <section className="py-20 bg-white" id="blog">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Industry Insights</h2>
          <p className="text-lg text-gray-600">
            Stay informed with our latest articles on power system analysis and electrical safety.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <div className="flex items-center mr-4">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{post.readTime}</span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{post.title}</h3>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <button className="text-blue-600 font-medium hover:text-blue-800 transition-colors inline-flex items-center">
                  Read more
                  <ChevronRight className="h-4 w-4 ml-1" />
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <button className="border border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors">
            View All Articles
          </button>
        </div>
      </div>
    </section>
  );
};

export default BlogInsights;