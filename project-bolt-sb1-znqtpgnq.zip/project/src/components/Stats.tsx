import React, { useEffect, useRef, useState } from 'react';
import { ShieldCheck, Clock, AlertTriangle, BarChart2 } from 'lucide-react';

const stats = [
  {
    icon: <ShieldCheck className="h-8 w-8 text-blue-600" />,
    value: 40,
    suffix: '%',
    label: 'Reduction in system failures',
    description: 'Average improvement reported by our clients'
  },
  {
    icon: <Clock className="h-8 w-8 text-blue-600" />,
    value: 99.9,
    suffix: '%',
    label: 'Uptime reliability',
    description: 'For systems under our management'
  },
  {
    icon: <AlertTriangle className="h-8 w-8 text-blue-600" />,
    value: 100,
    suffix: '%',
    label: 'Compliance rate',
    description: 'With AS/NZS, OSHA, and IEEE standards'
  },
  {
    icon: <BarChart2 className="h-8 w-8 text-blue-600" />,
    value: 25,
    suffix: '%',
    label: 'Average cost savings',
    description: 'Through preventive maintenance'
  }
];

const Stats = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const [counts, setCounts] = useState(stats.map(() => 0));

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const intervals = stats.map((stat, index) => {
      return setInterval(() => {
        setCounts(prevCounts => {
          const newCounts = [...prevCounts];
          if (newCounts[index] < stat.value) {
            newCounts[index] = Math.min(newCounts[index] + stat.value / 50, stat.value);
          }
          return newCounts;
        });
      }, 30);
    });

    return () => {
      intervals.forEach(interval => clearInterval(interval));
    };
  }, [isVisible]);

  return (
    <section ref={sectionRef} className="py-20 bg-blue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Measurable Impact Through Data-Driven Solutions
          </h2>
          <p className="text-lg text-gray-600">
            Our technical expertise translates into real, quantifiable benefits for your organization.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-lg shadow-md p-6 text-center transform transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="inline-flex items-center justify-center p-3 bg-blue-100 rounded-full mb-4">
                {stat.icon}
              </div>
              <div className="flex items-end justify-center mb-2">
                <span className="text-4xl font-bold text-gray-900">
                  {Math.round(counts[index])}
                </span>
                <span className="text-4xl font-bold text-gray-900">{stat.suffix}</span>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-1">{stat.label}</h3>
              <p className="text-sm text-gray-600">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;