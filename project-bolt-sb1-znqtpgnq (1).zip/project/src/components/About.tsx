import React from 'react';
import { Shield, Globe, Award, Users, CheckCircle, Zap } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg"
            alt="Power System Infrastructure"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50" />
        </div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Leading the Way in Electrical Safety Across Australia
            </h1>
            <p className="text-xl text-gray-100">
              Turning electrical challenges into safe, reliable, and compliant opportunities through expert power system analysis and consulting.
            </p>
          </div>
        </div>
      </section>

      {/* What Drives Us */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Powering Our Mission: Developing Reliable Solutions Together
            </h2>
            <p className="text-lg text-gray-600">
              At Care Labs Australia, we believe in proactive power system management that puts your safety and efficiency first. Our collaborative approach ensures cost-effective solutions that build lasting partnerships.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg">
              <Shield className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Safety First</h3>
              <p className="text-gray-600">
                Our unwavering commitment to electrical safety sets industry standards and protects your assets.
              </p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg">
              <Users className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Client Partnership</h3>
              <p className="text-gray-600">
                We build lasting relationships through transparent communication and dedicated support.
              </p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg">
              <Award className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence</h3>
              <p className="text-gray-600">
                Our expertise in power systems analysis ensures optimal performance and reliability.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Commitment to Excellence */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Our Commitment to Excellence
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <img
                src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg"
                alt="Modern Power Infrastructure"
                className="rounded-lg shadow-lg mb-8"
              />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Precision Engineering in Every Analysis
              </h3>
              <p className="text-gray-600">
                Our team employs cutting-edge ETAP software and industry-leading methodologies to deliver accurate, comprehensive power system analyses.
              </p>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/257886/pexels-photo-257886.jpeg"
                alt="Safety Compliance"
                className="rounded-lg shadow-lg mb-8"
              />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Proactive Safety with Regulatory Compliance
              </h3>
              <p className="text-gray-600">
                We ensure full compliance with AS/NZS standards while implementing forward-thinking safety measures that protect your assets and people.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Trust Us */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Why Trust Care Labs Australia?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-blue-50 p-8 rounded-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Pioneers in Power System Consulting
              </h3>
              <ul className="space-y-4">
                {[
                  'Advanced ETAP software implementation',
                  'Comprehensive technical expertise',
                  'Industry-leading methodologies',
                  'Continuous innovation in safety protocols'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-1" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-blue-50 p-8 rounded-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Worldwide Reach with Local Insight
              </h3>
              <ul className="space-y-4">
                {[
                  'Remote consultation capabilities',
                  'International standards compliance',
                  'Local Australian expertise',
                  'Global industry experience'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0 mt-1" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Global Presence */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <Globe className="h-16 w-16 text-blue-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Global Presence, Local Excellence
            </h2>
            <p className="text-lg text-gray-600">
              Our hybrid approach combines local expertise with global capabilities, serving clients across industries and continents.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              'Corporate Enterprises',
              'SME Businesses',
              'Public Sector',
              'International Organizations'
            ].map((sector, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                <Zap className="h-8 w-8 text-blue-600 mx-auto mb-4" />
                <h3 className="font-bold text-gray-900">{sector}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Where Proactive Safety Meets Power Engineering
          </h2>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-md font-medium transition-colors">
              Contact Us
            </button>
            <button className="bg-transparent border-2 border-white text-white hover:bg-white/10 px-8 py-4 rounded-md font-medium transition-colors">
              Schedule a Consultation
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;