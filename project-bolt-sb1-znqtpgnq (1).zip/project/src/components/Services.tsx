import React from 'react';
import { Zap, BarChart, Activity, Shield } from 'lucide-react';

const services = [
  {
    icon: <Zap className="h-10 w-10 text-blue-600" />,
    title: 'Arc Flash Analysis',
    description: 'Comprehensive assessment to identify potential electrical hazards and implement safety measures that comply with OSHA and IEEE standards.',
    features: ['Risk assessment', 'PPE recommendations', 'Safety labeling', 'Mitigation strategies']
  },
  {
    icon: <BarChart className="h-10 w-10 text-blue-600" />,
    title: 'Load Flow Studies',
    description: 'Detailed analysis of power flow distribution to optimize system performance, prevent overloads, and ensure efficient energy distribution.',
    features: ['System efficiency', 'Voltage profile analysis', 'Power factor correction', 'Loss minimization']
  },
  {
    icon: <Activity className="h-10 w-10 text-blue-600" />,
    title: 'Short Circuit Studies',
    description: 'Precise calculations to determine fault currents and ensure protection devices are properly rated to handle potential electrical faults.',
    features: ['Equipment rating verification', 'Protection coordination', 'Fault current analysis', 'System vulnerability detection']
  },
  {
    icon: <Shield className="h-10 w-10 text-blue-600" />,
    title: 'Compliance Consulting',
    description: 'Expert guidance to ensure your power systems meet all relevant AS/NZS, OSHA, and IEEE standards, avoiding penalties and ensuring safety.',
    features: ['Standards assessment', 'Compliance documentation', 'Regulatory updates', 'Audit preparation']
  }
];

const Services = () => {
  return (
    <section className="py-20 bg-gray-50\" id="services">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Specialized Services</h2>
          <p className="text-lg text-gray-600">
            Powered by industry-leading ETAP software, our services ensure the safety, 
            reliability, and compliance of your electrical power systems.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg shadow-md p-6 transition-transform duration-300 hover:-translate-y-2"
            >
              <div className="flex flex-col h-full">
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-6 flex-grow">{service.description}</p>
                <ul className="space-y-2 mb-4">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-gray-700">
                      <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="text-blue-600 font-medium hover:text-blue-800 transition-colors mt-auto inline-flex items-center">
                  Learn more
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;