import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  {
    question: "What standards do your power system analyses comply with?",
    answer: "Our analyses comply with all relevant industry standards including AS/NZS 3000, OSHA regulations, IEEE 1584 for Arc Flash calculations, and other applicable national and international standards. We stay current with all regulatory updates to ensure complete compliance."
  },
  {
    question: "How long does a typical power system analysis take?",
    answer: "The timeline varies depending on the size and complexity of your system. A small to medium facility analysis typically takes 2-3 weeks, while larger industrial complexes may require 4-6 weeks. We provide a detailed timeline estimate during our initial consultation."
  },
  {
    question: "What information do you need from us to conduct an analysis?",
    answer: "We require electrical single-line diagrams, equipment specifications (transformers, generators, motors, etc.), protection device settings, cable data, and load information. If you don't have all this information, our team can assist with gathering the necessary data through site visits and measurements."
  },
  {
    question: "How often should we update our power system analysis?",
    answer: "We recommend updating your power system analysis whenever significant changes are made to your electrical system, such as adding new equipment or modifying existing infrastructure. For facilities without changes, a review every 3-5 years is advisable to ensure ongoing compliance with updated standards."
  },
  {
    question: "Do you provide training for our staff on implementing your recommendations?",
    answer: "Yes, we offer comprehensive training programs tailored to your team's needs. These include safety protocol implementation, proper use of PPE based on arc flash analysis results, and understanding system operation limits identified in load flow studies."
  },
  {
    question: "What sets Care Labs Australia apart from other power system consultants?",
    answer: "Our combination of cutting-edge ETAP software analysis with hands-on practical expertise sets us apart. We don't just deliver technical reports; we provide actionable insights, implementation support, and ongoing guidance to ensure your power systems remain safe, reliable, and compliant."
  }
];

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  
  const toggleFAQ = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };
  
  return (
    <section className="py-20 bg-gray-50" id="faq">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-gray-600">
            Get answers to common questions about our power system analysis services.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`mb-4 border border-gray-200 rounded-lg overflow-hidden transition-all duration-300 ${
                activeIndex === index ? 'shadow-md' : ''
              }`}
            >
              <button
                className="w-full text-left p-4 md:p-6 bg-white flex justify-between items-center focus:outline-none"
                onClick={() => toggleFAQ(index)}
              >
                <span className="font-medium text-gray-900">{faq.question}</span>
                {activeIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-blue-600 flex-shrink-0" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-600 flex-shrink-0" />
                )}
              </button>
              <div 
                className={`px-4 md:px-6 transition-all duration-300 ease-in-out overflow-hidden ${
                  activeIndex === index ? 'max-h-96 pb-6' : 'max-h-0'
                }`}
              >
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-700 mb-4">Still have questions?</p>
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium transition-colors">
            Contact Our Experts
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQ;